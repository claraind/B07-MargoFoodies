@extends('default') 
@section('content') 
  {{ "Getting Started with Blade Template " }} 
@stop