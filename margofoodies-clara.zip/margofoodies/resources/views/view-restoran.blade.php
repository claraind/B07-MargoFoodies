@extends('master')

@section('contents')
<div class="container" >
  <div class="row">
        <div class="col-sm-4 col-sm-offset-4">
		<h1> Ayo Kunjungi Restoran kami! </h1>
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="../images/menu03.jpg" alt="Chania" width="1000" height="800">
      </div>

      <div class="item">
        <img src="../images/menu03.jpg" alt="Chania" width="1000" height="800">
      </div>
    
      <div class="item">
        <img src="../images/menu03.jpg" alt="Flower" width="1000" height="800">
      </div>

      <div class="item">
        <img src="../images/menu03.jpg" alt="Flower" width="1000" height="800">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
  </div>
  </div>
  @if(count($restoran))

	<h3 id="name"><b>{{$restoran->nama}}</b></h3>
	<h4 id="deskripsi"> {{$restoran->deskripsi}} </h4>
	<h4 id="lokasi"> Lokasi : {{$restoran->lokasi}}</h4>
	<h4 id="no-telp">  </h4>
	<h4 id="tax"> Tax : {{$restoran->tax}}%</h4>
	<h4 id="rate"> Rate : {{$restoran->rate}} </h4>

	
	<h4> Jenis Masakan : </h4>
	<ul>
	@foreach($jenis_masakans as $jenis_masakan)
		<li>{{$jenis_masakan->jenis_masakan}} </li>
	@endforeach
	</ul>

	<h4> Waktu Operasional : </h4>
	<ul>
	@foreach($waktu_operasionals as $waktu_operasional)
		<li> {{$waktu_operasional->hari}} :  {{$waktu_operasional->waktu_buka}} - {{$waktu_operasional->waktu_tutup}} </li>

	@endforeach
	</ul>

	<h4> Fasilitas : </h4>
	<ul>
	@foreach($fasilitas_restorans as $fasilitas_restoran)
		<li> {{$fasilitas_restoran->nama_fasilitas}} </li>

	@endforeach
	</ul>

	<h4> Daftar Menu </h4>
	<table border="2">
	<th> nama </th>
	<th> harga </th>
	<th> </th>
	@foreach($menus as $menu)
		<tr>
		<td> {{$menu->nama}} </td>
		<td> {{$menu->harga}} </td>
		<td> <a href="../menu/{{$menu->id}}">lihat </a></td>

		</tr>
	@endforeach
	</table>
@endif
</div>

@stop




