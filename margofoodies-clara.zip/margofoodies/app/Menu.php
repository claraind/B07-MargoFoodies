<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Menu extends Model {

	//
	public function restoran()
    {
        return $this->hasOne('Restoran');
    }

}
