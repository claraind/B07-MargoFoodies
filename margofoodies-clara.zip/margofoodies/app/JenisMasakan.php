<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class JenisMasakan extends Model {

	//
	public function restoran()
    {
        return $this->hasOne('Restoran');
    }

}
