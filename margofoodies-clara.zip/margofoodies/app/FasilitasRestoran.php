<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class FasilitasRestoran extends Model {

	//
	public function restoran()
    {
        return $this->hasOne('Restoran');
    }


}
