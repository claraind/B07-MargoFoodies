<?php
	/**
	* Ini contoh aja, tergantung web kita nanti gimana
	*
	*/
	session_start();
	$connect = pg_connect("host=ipin.cs.ui.ac.id dbname=ppw user=ppw password=ppw123");

	if(!empty($_SESSION["user"])) {
		header("Location: home.php");
	} else {
		if($_SERVER["REQUEST_METHOD"] == "POST") {

			// Validasi username
			if(empty($_POST["username"])) {
				$_SESSION["loginerror"] = "NPM is needed to proceed!";
				header("Location: index.php");
			} else {
				$query = "SET SEARCH_PATH TO '1306386895';
						SELECT * FROM mahasiswa WHERE npm='".$_POST["username"]."';";
				echo $query;
				$result = pg_query($connect, $query);
				$row = pg_fetch_array($result);
				
				if ($row == null) {
					$_SESSION["loginerror"] = "You Shall Not Pass!";
					header("Location: index.php");
				} else {
					$_SESSION["user"] = $row[0];
					header("Location: home.php");
				}
			}
		}
	}	
?>